# sw1c2r

The dataset is splited into train, val and test with 200k, 5k, 5k samples respectively, fully following setting of [NeuralDialog-CVAE](https://github.com/snakeztc/NeuralDialog-CVAE).

Vocab size is set to 10000 and embeded with glove.twitter.27B.200d from [Glove](https://nlp.stanford.edu/projects/glove/).
